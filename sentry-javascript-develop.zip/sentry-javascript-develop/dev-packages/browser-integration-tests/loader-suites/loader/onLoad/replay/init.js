Sentry.onLoad(function () {
  Sentry.init({
    replaysSessionSampleRate: 1,
  });
});

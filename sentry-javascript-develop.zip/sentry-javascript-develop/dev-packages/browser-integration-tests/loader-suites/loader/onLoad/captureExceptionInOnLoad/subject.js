Sentry.forceLoad();

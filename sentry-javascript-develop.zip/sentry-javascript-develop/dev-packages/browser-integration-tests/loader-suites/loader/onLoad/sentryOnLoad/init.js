// we define sentryOnLoad in template

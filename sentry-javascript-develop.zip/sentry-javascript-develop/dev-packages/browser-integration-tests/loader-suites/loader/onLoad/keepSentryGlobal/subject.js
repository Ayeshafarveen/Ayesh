Sentry.forceLoad();

Sentry.captureException('Test exception');

Sentry.onLoad(function () {
  Sentry.init({});
});

setTimeout(() => {
  window.doSomethingWrong();
}, 500);

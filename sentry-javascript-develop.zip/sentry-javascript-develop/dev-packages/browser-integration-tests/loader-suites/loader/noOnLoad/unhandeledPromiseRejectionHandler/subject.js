new Promise(function (resolve, reject) {
  reject('this is unhandled');
});

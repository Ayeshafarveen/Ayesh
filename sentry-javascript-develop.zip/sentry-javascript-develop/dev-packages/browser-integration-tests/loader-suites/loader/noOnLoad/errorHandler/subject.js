window.doSomethingWrong();

Sentry.captureException('Test exception');

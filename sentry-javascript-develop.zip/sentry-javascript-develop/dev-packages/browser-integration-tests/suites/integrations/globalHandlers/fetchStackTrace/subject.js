fetch('http://localhost:123/fake/endpoint/that/will/fail');

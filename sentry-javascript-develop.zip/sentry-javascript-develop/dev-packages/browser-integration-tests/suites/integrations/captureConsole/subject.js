console.log('console log');
console.warn('console warn');
console.error('console error');
console.info('console info');
console.trace('console trace');

console.error(new Error('console error with error object'));
console.trace(new Error('console trace with error object'));

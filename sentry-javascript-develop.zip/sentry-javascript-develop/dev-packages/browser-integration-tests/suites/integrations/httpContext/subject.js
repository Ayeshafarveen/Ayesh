window._sentryScope.captureException(new Error('client init'));

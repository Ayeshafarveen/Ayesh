requestAnimationFrame(function () {
  throw new Error('requestAnimationFrame_error');
});

Sentry.addBreadcrumb();

Sentry.captureMessage('test_undefined_arg');

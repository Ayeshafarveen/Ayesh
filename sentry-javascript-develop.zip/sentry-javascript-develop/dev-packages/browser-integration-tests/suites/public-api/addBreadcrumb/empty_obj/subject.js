Sentry.addBreadcrumb({});

Sentry.captureMessage('test_empty_obj');

Sentry.captureException(new Error('test error'));

window._testDone = true;

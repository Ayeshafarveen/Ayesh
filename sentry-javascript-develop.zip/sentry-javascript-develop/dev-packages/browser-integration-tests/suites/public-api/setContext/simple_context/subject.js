Sentry.setContext('foo', { bar: 'baz' });
Sentry.captureMessage('simple_context_object');

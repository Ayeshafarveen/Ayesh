Sentry.captureException(new Error('foo'));
Sentry.captureException(new Error('ignoreErrorTest'));
Sentry.captureException(new Error('bar'));

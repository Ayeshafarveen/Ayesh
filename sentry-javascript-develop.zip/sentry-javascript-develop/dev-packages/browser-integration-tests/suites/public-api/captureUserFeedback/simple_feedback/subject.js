Sentry.captureUserFeedback({
  eventId: 'test_event_id',
  email: 'test_email',
  comments: 'test_comments',
  name: 'test_name',
});

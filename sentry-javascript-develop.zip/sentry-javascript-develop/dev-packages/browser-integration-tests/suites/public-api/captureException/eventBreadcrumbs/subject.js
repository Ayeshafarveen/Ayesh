Sentry.captureMessage('a');

Sentry.captureException(new Error('test_simple_breadcrumb_error'));

Sentry.captureException(new Event('custom'));

Sentry.captureException({
  prop1: 'value1',
  prop2: 2,
});

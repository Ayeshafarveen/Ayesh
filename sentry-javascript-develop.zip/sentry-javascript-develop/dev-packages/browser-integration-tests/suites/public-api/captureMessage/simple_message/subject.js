Sentry.captureMessage('foo');

Sentry.captureMessage('debug_message', 'debug');
Sentry.captureMessage('info_message', 'info');
Sentry.captureMessage('warning_message', 'warning');
Sentry.captureMessage('error_message', 'error');
Sentry.captureMessage('fatal_message', 'fatal');
Sentry.captureMessage('log_message', 'log');

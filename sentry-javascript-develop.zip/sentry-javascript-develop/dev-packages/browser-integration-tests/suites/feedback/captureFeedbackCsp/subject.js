window.__CSPVIOLATION__ = false;
document.addEventListener('securitypolicyviolation', () => {
  window.__CSPVIOLATION__ = true;
});

---
title: '{{ env.TITLE }}'
labels: 'Type: Tests, Waiting for: Product Owner'
---

Canary tests failed: {{ env.RUN_LINK }}
